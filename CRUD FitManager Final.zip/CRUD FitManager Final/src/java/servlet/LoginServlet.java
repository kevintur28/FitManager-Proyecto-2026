package servlet;

import Controlador.Conexion;
import Controlador.UsuariosDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import modelo.Usuarios;

import java.io.IOException;
import java.sql.Connection;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String correo =
                request.getParameter("correo");

        String password =
                request.getParameter("password");

        try {

            Connection conn =
                    Conexion.getConnect();

            UsuariosDAO dao =
                    new UsuariosDAO(conn);

            Usuarios usuario =
                    dao.consultarPorEmail(correo);

            // Usuario existe
            if (usuario != null &&
                    usuario.getPassword().equals(password)) {

                HttpSession session =
                        request.getSession();

                // Guardar usuario completo
                session.setAttribute(
                        "usuario",
                        usuario
                );

                session.setAttribute(
                        "nombre",
                        usuario.getNombre()
                        + " "
                        + usuario.getApellido()
                );

                session.setAttribute(
                        "correo",
                        usuario.getEmail()
                );

                session.setAttribute(
                        "idUsuario",
                        usuario.getId_Usuarios()
                );

                session.setAttribute(
                        "rol",
                        usuario.getId_Roles()
                );

                // ADMIN = 1
                if (usuario.getId_Roles() == 1) {

                    response.sendRedirect(
                            request.getContextPath()
                                    + "/admin.jsp"
                    );

                } else {

                    response.sendRedirect(
                            request.getContextPath()
                                    + "/cliente.jsp"
                    );
                }

                return;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect(
                request.getContextPath()
                        + "/Login.jsp?error=1"
        );
    }
}