package Modelo;

public class FactCabecera {

    private int id_Fact_Cabecera;
    private String fecha_fact;
    private String n_factura;
    private String valortotal;
    private int id_metodopago;
    private int id_usuarios;

    public int getId_Fact_Cabecera() {
        return id_Fact_Cabecera;
    }

    public void setId_Fact_Cabecera(int id_Fact_Cabecera) {
        this.id_Fact_Cabecera = id_Fact_Cabecera;
    }

    public String getFecha_fact() {
        return fecha_fact;
    }

    public void setFecha_fact(String fecha_fact) {
        this.fecha_fact = fecha_fact;
    }

    public String getN_factura() {
        return n_factura;
    }

    public void setN_factura(String n_factura) {
        this.n_factura = n_factura;
    }

    public String getValortotal() {
        return valortotal;
    }

    public void setValortotal(String valortotal) {
        this.valortotal = valortotal;
    }

    public int getId_metodopago() {
        return id_metodopago;
    }

    public void setId_metodopago(int id_metodopago) {
        this.id_metodopago = id_metodopago;
    }

    public int getId_usuarios() {
        return id_usuarios;
    }

    public void setId_usuarios(int id_usuarios) {
        this.id_usuarios = id_usuarios;
    }
}