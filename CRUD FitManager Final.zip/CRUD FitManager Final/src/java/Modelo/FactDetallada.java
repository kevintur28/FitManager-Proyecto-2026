package Modelo;

public class FactDetallada {

    private int id_Fact_Detallada;
    private String cantidad;
    private int id_productos;
    private int id_Fact_Cabecera;

    public int getId_Fact_Detallada() {
        return id_Fact_Detallada;
    }

    public void setId_Fact_Detallada(int id_Fact_Detallada) {
        this.id_Fact_Detallada = id_Fact_Detallada;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public int getId_productos() {
        return id_productos;
    }

    public void setId_productos(int id_productos) {
        this.id_productos = id_productos;
    }

    public int getId_Fact_Cabecera() {
        return id_Fact_Cabecera;
    }

    public void setId_Fact_Cabecera(int id_Fact_Cabecera) {
        this.id_Fact_Cabecera = id_Fact_Cabecera;
    }
}