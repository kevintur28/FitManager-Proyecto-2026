package Modelo;

public class Roles {

    private int id_Roles;
    private String descripcion;

    public Roles() {}

    public Roles(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getId_Roles() {
        return id_Roles;
    }

    public void setId_Roles(int id_Roles) {
        this.id_Roles = id_Roles;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}