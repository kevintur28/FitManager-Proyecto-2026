package Modelo;

public class EvaluacionesFisicas {

    private int id_EvaluacionesFisicas;
    private String fecha;
    private double peso;
    private int edad;
    private String condicion;
    private String pruebas;
    private int id_Usuarios;

    public int getId_EvaluacionesFisicas() {
        return id_EvaluacionesFisicas;
    }

    public void setId_EvaluacionesFisicas(int id) {
        this.id_EvaluacionesFisicas = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCondicion() {
        return condicion;
    }

    public void setCondicion(String condicion) {
        this.condicion = condicion;
    }

    public String getPruebas() {
        return pruebas;
    }

    public void setPruebas(String pruebas) {
        this.pruebas = pruebas;
    }

    public int getId_Usuarios() {
        return id_Usuarios;
    }

    public void setId_Usuarios(int id_Usuarios) {
        this.id_Usuarios = id_Usuarios;
    }
}