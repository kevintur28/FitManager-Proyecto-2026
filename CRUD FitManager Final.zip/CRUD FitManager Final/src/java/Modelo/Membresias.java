package Modelo;

public class Membresias {

    private int id_Membresias;
    private double precio;
    private String tipo;
    private int duracion_dias;

    public int getId_Membresias() {
        return id_Membresias;
    }

    public void setId_Membresias(int id_Membresias) {
        this.id_Membresias = id_Membresias;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getDuracion_dias() {
        return duracion_dias;
    }

    public void setDuracion_dias(int duracion_dias) {
        this.duracion_dias = duracion_dias;
    }

    }