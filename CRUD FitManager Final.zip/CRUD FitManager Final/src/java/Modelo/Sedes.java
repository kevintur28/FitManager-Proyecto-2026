package Modelo;

public class Sedes {

    public int getIdSedes() {
        return idSedes;
    }

    public void setIdSedes(int idSedes) {
        this.idSedes = idSedes;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    private int idSedes;
    private String nombre;
    private String direccion;


}
