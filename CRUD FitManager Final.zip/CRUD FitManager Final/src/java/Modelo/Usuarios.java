package modelo;

import java.io.Serializable;

public class Usuarios implements Serializable {

    private static final long serialVersionUID = 1L;

    private int id_Usuarios;
    private String nombre;
    private String apellido;
    private String documento;
    private String email;
    private int id_TipoDocumento;
    private int id_Roles;
    private String password;
    private int id_Membresias;

    public Usuarios() {
    }

    public int getId_Usuarios() {
        return id_Usuarios;
    }

    public void setId_Usuarios(int id_Usuarios) {
        this.id_Usuarios = id_Usuarios;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId_TipoDocumento() {
        return id_TipoDocumento;
    }

    public void setId_TipoDocumento(int id_TipoDocumento) {
        this.id_TipoDocumento = id_TipoDocumento;
    }

    public int getId_Roles() {
        return id_Roles;
    }

    public void setId_Roles(int id_Roles) {
        this.id_Roles = id_Roles;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId_Membresias() {
        return id_Membresias;
    }

    public void setId_Membresias(int id_Membresias) {
        this.id_Membresias = id_Membresias;
    }
}
