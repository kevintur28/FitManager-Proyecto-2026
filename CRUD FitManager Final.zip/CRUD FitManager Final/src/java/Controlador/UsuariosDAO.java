package Controlador;

import modelo.Usuarios;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuariosDAO {

    private Connection conn;

    public UsuariosDAO(Connection conn) {
        this.conn = conn;
    }

    public UsuariosDAO() {
        this.conn = Conexion.getConnect();
        if (this.conn == null) {
            throw new RuntimeException("Error: conexión a la base de datos es NULL.");
        }
    }

    // =========================
    // INSERTAR
    // =========================
    public boolean insertar(Usuarios u) {
        String sql = "INSERT INTO usuarios (nombre, apellido, documento, email, id_Roles, id_Membresias, password, id_TipoDocumento) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, u.getNombre());
            stmt.setString(2, u.getApellido());
            stmt.setString(3, u.getDocumento());
            stmt.setString(4, u.getEmail());
            stmt.setInt(5, u.getId_Roles());
            stmt.setInt(6, u.getId_Membresias());
            stmt.setString(7, u.getPassword());
            stmt.setInt(8, u.getId_TipoDocumento());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // =========================
    // LOGIN
    // =========================
    public Usuarios consultarPorEmail(String email) {
        Usuarios usuario = null;
        String sql = "SELECT * FROM usuarios WHERE email = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                usuario = new Usuarios();
                usuario.setId_Usuarios(rs.getInt("id_Usuarios"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setApellido(rs.getString("apellido"));
                usuario.setDocumento(rs.getString("documento"));
                usuario.setEmail(rs.getString("email"));
                usuario.setId_Roles(rs.getInt("id_Roles"));
                usuario.setId_Membresias(rs.getInt("id_Membresias"));
                usuario.setPassword(rs.getString("password"));
                usuario.setId_TipoDocumento(rs.getInt("id_TipoDocumento"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return usuario;
    }

    // =========================
    // LISTAR
    // =========================
    public List<Usuarios> listar() {
        List<Usuarios> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Usuarios u = new Usuarios();
                u.setId_Usuarios(rs.getInt("id_Usuarios"));
                u.setNombre(rs.getString("nombre"));
                u.setApellido(rs.getString("apellido"));
                u.setDocumento(rs.getString("documento"));
                u.setEmail(rs.getString("email"));
                u.setId_Roles(rs.getInt("id_Roles"));
                u.setId_Membresias(rs.getInt("id_Membresias"));
                u.setPassword(rs.getString("password"));
                u.setId_TipoDocumento(rs.getInt("id_TipoDocumento"));
                lista.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    // =========================
    // ACTUALIZAR
    // =========================
    public boolean actualizar(Usuarios u) {
        // ← coma extra eliminada antes de WHERE
        String sql = "UPDATE usuarios SET nombre=?, apellido=?, documento=?, email=?, id_Roles=?, id_Membresias=?, password=?, id_TipoDocumento=? WHERE id_Usuarios=?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, u.getNombre());
            stmt.setString(2, u.getApellido());
            stmt.setString(3, u.getDocumento());
            stmt.setString(4, u.getEmail());
            stmt.setInt(5, u.getId_Roles());
            stmt.setInt(6, u.getId_Membresias());
            stmt.setString(7, u.getPassword());
            stmt.setInt(8, u.getId_TipoDocumento());
            stmt.setInt(9, u.getId_Usuarios());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // =========================
    // ELIMINAR
    // =========================
    public boolean eliminar(int id) {
        String sql = "DELETE FROM usuarios WHERE id_Usuarios = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}