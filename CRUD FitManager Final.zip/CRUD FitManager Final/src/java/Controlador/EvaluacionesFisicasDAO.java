/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.EvaluacionesFisicas;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EvaluacionesFisicasDAO {

    private Connection conn;

    public EvaluacionesFisicasDAO(Connection conn) {
        this.conn = conn;
    }

    public EvaluacionesFisicasDAO() {
    }

    // INSERTAR
    public boolean insertar(EvaluacionesFisicas e) {
        String sql = "INSERT INTO evaluacionesfisicas (fecha, peso, edad, condicion, pruebas, id_Usuarios) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, e.getFecha());
            stmt.setDouble(2, e.getPeso());
            stmt.setInt(3, e.getEdad());
            stmt.setString(4, e.getCondicion());
            stmt.setString(5, e.getPruebas());
            stmt.setInt(6, e.getId_Usuarios());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e1) {
            e1.printStackTrace();
            return false;
        }
    }

    // CONSULTAR
    public EvaluacionesFisicas consultar(int id) {
        EvaluacionesFisicas e = null;

        try {
            String sql = "SELECT * FROM evaluacionesfisicas WHERE id_EvaluacionesFisicas = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                e = new EvaluacionesFisicas();
                e.setId_EvaluacionesFisicas(rs.getInt("id_EvaluacionesFisicas"));
                e.setFecha(rs.getString("fecha"));
                e.setPeso(rs.getDouble("peso"));
                e.setEdad(rs.getInt("edad"));
                e.setCondicion(rs.getString("condicion"));
                e.setPruebas(rs.getString("pruebas"));
                e.setId_Usuarios(rs.getInt("id_Usuarios"));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return e;
    }

    // LISTAR
    public List<EvaluacionesFisicas> listar() {
        List<EvaluacionesFisicas> lista = new ArrayList<>();
        String sql = "SELECT * FROM evaluacionesfisicas";

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                EvaluacionesFisicas e = new EvaluacionesFisicas();

                e.setId_EvaluacionesFisicas(rs.getInt("id_EvaluacionesFisicas"));
                e.setFecha(rs.getString("fecha"));
                e.setPeso(rs.getDouble("peso"));
                e.setEdad(rs.getInt("edad"));
                e.setCondicion(rs.getString("condicion"));
                e.setPruebas(rs.getString("pruebas"));
                e.setId_Usuarios(rs.getInt("id_Usuarios"));

                lista.add(e);
            }

        } catch (SQLException e1) {
            e1.printStackTrace();
        }

        return lista;
    }

    // ACTUALIZAR
    public boolean actualizar(EvaluacionesFisicas e) {
        String sql = "UPDATE evaluacionesfisicas SET fecha=?, peso=?, edad=?, condicion=?, pruebas=?, id_Usuarios=? WHERE id_EvaluacionesFisicas=?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, e.getFecha());
            stmt.setDouble(2, e.getPeso());
            stmt.setInt(3, e.getEdad());
            stmt.setString(4, e.getCondicion());
            stmt.setString(5, e.getPruebas());
            stmt.setInt(6, e.getId_Usuarios());
            stmt.setInt(7, e.getId_EvaluacionesFisicas());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e1) {
            e1.printStackTrace();
            return false;
        }
    }

    // ELIMINAR
    public boolean eliminar(int id) {
        String sql = "DELETE FROM evaluacionesfisicas WHERE id_EvaluacionesFisicas=?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e1) {
            e1.printStackTrace();
            return false;
        }
    }
}