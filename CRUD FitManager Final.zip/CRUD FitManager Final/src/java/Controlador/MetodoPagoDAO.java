package Controlador;

import java.sql.*;
import java.util.ArrayList;
import Modelo.MetodoPago;

public class MetodoPagoDAO {

    private Connection conn;

    public MetodoPagoDAO() {
        conn = new Conexion().getConnection();
    }

    // INSERTAR
    public boolean insertar(MetodoPago mp) {
        String sql = "INSERT INTO MetodoPago(descripcion) VALUES(?)";

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, mp.getDescripcion());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("Error al insertar: " + e.getMessage());
            return false;
        }
    }

    // CONSULTAR
    public MetodoPago consultar(int id) {
        MetodoPago mp = null;
        String sql = "SELECT * FROM MetodoPago WHERE id_metodopago=?";

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                mp = new MetodoPago();
                mp.setIdMetodoPago(rs.getInt("id_metodopago"));
                mp.setDescripcion(rs.getString("descripcion"));
            }

        } catch (Exception e) {
            System.out.println("Error al consultar: " + e.getMessage());
        }

        return mp;
    }

    // ACTUALIZAR
    public boolean actualizar(MetodoPago mp) {
        String sql = "UPDATE MetodoPago SET descripcion=? WHERE id_metodopago=?";

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, mp.getDescripcion());
            ps.setInt(2, mp.getIdMetodoPago());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("Error al actualizar: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR
    public boolean eliminar(int id) {
        String sql = "DELETE FROM MetodoPago WHERE id_metodopago=?";

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("Error al eliminar: " + e.getMessage());
            return false;
        }
    }

    // LISTAR
    public ArrayList<MetodoPago> listar() {
        ArrayList<MetodoPago> lista = new ArrayList<>();
        String sql = "SELECT * FROM MetodoPago";

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                MetodoPago mp = new MetodoPago();
                mp.setIdMetodoPago(rs.getInt("id_metodopago"));
                mp.setDescripcion(rs.getString("descripcion"));
                lista.add(mp);
            }
        } catch (Exception e) {
            System.out.println("Error al listar: " + e.getMessage());
        }

        return lista;
    }
}