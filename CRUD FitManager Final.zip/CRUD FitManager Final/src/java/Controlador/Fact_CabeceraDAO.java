package Controlador;

import java.sql.*;
import Modelo.FactCabecera;

public class Fact_CabeceraDAO {

    Conexion conexion = new Conexion();

    // INSERTAR
    public boolean insertar(FactCabecera f) {

        try {
            Connection conn = conexion.getConnection();

            String sql = "INSERT INTO Fact_Cabecera (fecha_fact, n_factura, valortotal, id_metodopago, id_usuarios) VALUES (?, ?, ?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, f.getFecha_fact());
            ps.setString(2, f.getN_factura());
            ps.setString(3, f.getValortotal());
            ps.setInt(4, f.getId_metodopago());
            ps.setInt(5, f.getId_usuarios());

            ps.executeUpdate();
            conn.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al insertar factura: " + e.getMessage());
            return false;
        }
    }
    // CONSULTAR
    public FactCabecera consultaFactCabecera(int id_Fact_Cabecera) {

    FactCabecera fact = null;
    Connection conn = conexion.getConnection();

        try {

            String sql = "SELECT id_Fact_Cabecera, fecha_fact, n_factura, valortotal, id_metodopago, id_usuarios " +
                    "FROM Fact_Cabecera WHERE id_Fact_Cabecera=?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id_Fact_Cabecera);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                fact = new FactCabecera();
                fact.setId_Fact_Cabecera(rs.getInt(1));
                fact.setFecha_fact(rs.getString(2));
                fact.setN_factura(rs.getString(3));
                fact.setValortotal(rs.getString(4));
                fact.setId_metodopago(rs.getInt(5));
                fact.setId_usuarios(rs.getInt(6));
            }

            return fact;

        } catch (SQLException e) {
            System.out.println("Error al consultar factura: " + e.getMessage());
            return fact;
        }
    }

    // ACTUALIZAR
    public boolean actualizar(FactCabecera f) {

        try {
            Connection conn = conexion.getConnection();

            String sql = "UPDATE Fact_Cabecera SET fecha_fact=?, n_factura=?, valortotal=?, id_metodopago=?, id_usuarios=? WHERE id_Fact_Cabecera=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, f.getFecha_fact());
            ps.setString(2, f.getN_factura());
            ps.setString(3, f.getValortotal());
            ps.setInt(4, f.getId_metodopago());
            ps.setInt(5, f.getId_usuarios());
            ps.setInt(6, f.getId_Fact_Cabecera());

            ps.executeUpdate();
            conn.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al actualizar factura: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR
    public boolean eliminar(int id) {

        try {
            Connection conn = conexion.getConnection();

            String sql = "DELETE FROM Fact_Cabecera WHERE id_Fact_Cabecera=?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            ps.executeUpdate();
            conn.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al eliminar factura: " + e.getMessage());
            return false;
        }
    }
}