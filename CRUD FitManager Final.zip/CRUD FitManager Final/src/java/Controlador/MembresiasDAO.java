package Controlador;

import Modelo.Membresias;
import java.sql.*;

public class MembresiasDAO {

    private Connection conectar() {
        try {
            return DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/fitmanager?useSSL=false&serverTimezone=UTC",
                "root",
                ""
            );
        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
            return null;
        }
    }

    // INSERTAR
    public boolean insertar(Membresias m) {

        String sql = "INSERT INTO membresias (precio, tipo, duracion_dias, Fecha_vencimiento) VALUES (?, ?, ?, ?)";

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDouble(1, m.getPrecio());
            ps.setString(2, m.getTipo());
            ps.setInt(3, m.getDuracion_dias());

            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al insertar: " + e.getMessage());
            return false;
        }
    }

    // CONSULTAR
    public Membresias consultar(int id) {

        Membresias m = null;
        String sql = "SELECT * FROM membresias WHERE id_Membresias=?";

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                m = new Membresias();
                m.setId_Membresias(rs.getInt("id_Membresias"));
                m.setPrecio(rs.getDouble("precio"));
                m.setTipo(rs.getString("tipo"));
                m.setDuracion_dias(rs.getInt("duracion_dias"));
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar: " + e.getMessage());
        }

        return m;
    }

    // ACTUALIZAR
    public boolean actualizar(Membresias m) {

        String sql = "UPDATE membresias SET precio=?, tipo=?, duracion_dias=?, Fecha_vencimiento=? WHERE id_Membresias=?";

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDouble(1, m.getPrecio());
            ps.setString(2, m.getTipo());
            ps.setInt(3, m.getDuracion_dias());
            ps.setInt(4, m.getId_Membresias());

            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al actualizar: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR
    public boolean eliminar(int id) {

        String sql = "DELETE FROM membresias WHERE id_Membresias=?";

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al eliminar: " + e.getMessage());
            return false;
        }
    }
}