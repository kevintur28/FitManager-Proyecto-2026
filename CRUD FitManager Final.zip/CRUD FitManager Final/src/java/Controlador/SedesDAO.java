package Controlador;

import Modelo.Sedes;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SedesDAO {

    private Connection conn;

    public SedesDAO(Connection conn) {
        this.conn = conn;
    }

    // INSERTAR
    public boolean insertar(Sedes sede) {
        String sql = "INSERT INTO Sedes (Nombre, Direccion) VALUES (?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, sede.getNombre());
            stmt.setString(2, sede.getDireccion());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al insertar: " + e.getMessage());
            return false;
        }
    }

    // CONSULTAR (igual a buscarPorId pero con el mismo nombre que usas en otros DAOs)
    public Sedes consultar(int id) {
        Sedes s = null;
        String sql = "SELECT * FROM Sedes WHERE id_Sedes=?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                s = new Sedes();
                s.setIdSedes(rs.getInt("id_Sedes"));
                s.setNombre(rs.getString("Nombre"));
                s.setDireccion(rs.getString("Direccion"));
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar: " + e.getMessage());
        }

        return s;
    }

    // ACTUALIZAR
    public boolean actualizar(Sedes sede) {
        String sql = "UPDATE Sedes SET Nombre=?, Direccion=? WHERE id_Sedes=?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, sede.getNombre());
            stmt.setString(2, sede.getDireccion());
            stmt.setInt(3, sede.getIdSedes());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al actualizar: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR
    public boolean eliminar(int id) {
        String sql = "DELETE FROM Sedes WHERE id_Sedes=?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error al eliminar: " + e.getMessage());
            return false;
        }
    }

    // LISTAR
    public List<Sedes> listar() {
        List<Sedes> lista = new ArrayList<>();
        String sql = "SELECT * FROM Sedes";

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Sedes s = new Sedes();
                s.setIdSedes(rs.getInt("id_Sedes"));
                s.setNombre(rs.getString("Nombre"));
                s.setDireccion(rs.getString("Direccion"));
                lista.add(s);
            }

        } catch (SQLException e) {
            System.out.println("Error al listar: " + e.getMessage());
        }

        return lista;
    }

    // BUSCAR POR ID (lo dejas porque ya lo tenías)
    public Sedes buscarPorId(int id) {
        String sql = "SELECT * FROM Sedes WHERE id_Sedes=?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Sedes s = new Sedes();
                s.setIdSedes(rs.getInt("id_Sedes"));
                s.setNombre(rs.getString("Nombre"));
                s.setDireccion(rs.getString("Direccion"));
                return s;
            }

        } catch (SQLException e) {
            System.out.println("Error al buscar: " + e.getMessage());
        }

        return null;
    }
}