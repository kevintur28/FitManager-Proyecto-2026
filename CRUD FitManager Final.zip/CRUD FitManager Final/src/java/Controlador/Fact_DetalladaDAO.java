package Controlador;

import java.sql.*;
import Modelo.FactDetallada;

public class Fact_DetalladaDAO {

    Conexion conexion = new Conexion();

    // INSERTAR
    public boolean insertar(FactDetallada f) {

        try {
            Connection conn = conexion.getConnection();

            String sql = "INSERT INTO Fact_Detallada (cantidad, id_productos, id_Fact_Cabecera) VALUES (?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, f.getCantidad());
            ps.setInt(2, f.getId_productos());
            ps.setInt(3, f.getId_Fact_Cabecera());

            ps.executeUpdate();
            conn.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al insertar detalle: " + e.getMessage());
            return false;
        }
    }

    // CONSULTAR
    public FactDetallada consultar(int id) {

        FactDetallada f = null;

        try {
            Connection conn = conexion.getConnection();

            String sql = "SELECT * FROM Fact_Detallada WHERE id_Fact_Detallada=?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                f = new FactDetallada();
                f.setId_Fact_Detallada(rs.getInt("id_Fact_Detallada"));
                f.setCantidad(rs.getString("cantidad"));
                f.setId_productos(rs.getInt("id_productos"));
                f.setId_Fact_Cabecera(rs.getInt("id_Fact_Cabecera"));
            }

            conn.close();

        } catch (SQLException e) {
            System.out.println("Error al consultar: " + e.getMessage());
        }

        return f;
    }

    // ACTUALIZAR
    public boolean actualizar(FactDetallada f) {

        try {
            Connection conn = conexion.getConnection();

            String sql = "UPDATE Fact_Detallada SET cantidad=?, id_productos=?, id_Fact_Cabecera=? WHERE id_Fact_Detallada=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, f.getCantidad());
            ps.setInt(2, f.getId_productos());
            ps.setInt(3, f.getId_Fact_Cabecera());
            ps.setInt(5, f.getId_Fact_Detallada());

            ps.executeUpdate();
            conn.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al actualizar: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR
    public boolean eliminar(int id) {

        try {
            Connection conn = conexion.getConnection();

            String sql = "DELETE FROM Fact_Detallada WHERE id_Fact_Detallada=?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            ps.executeUpdate();
            conn.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al eliminar: " + e.getMessage());
            return false;
        }
    }
}