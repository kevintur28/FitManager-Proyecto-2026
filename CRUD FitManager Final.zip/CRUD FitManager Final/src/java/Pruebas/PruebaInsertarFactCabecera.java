/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pruebas;

import Controlador.Fact_CabeceraDAO;
import java.util.Scanner;
import Modelo.FactCabecera;

public class PruebaInsertarFactCabecera {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        FactCabecera factura = new FactCabecera();
        Fact_CabeceraDAO dao = new Fact_CabeceraDAO();

        System.out.println("1. Insertar");
        System.out.println("2. Actualizar");
        System.out.println("3. Eliminar");
        System.out.print("Seleccione opcion: ");
        int opcion = sc.nextInt();
        sc.nextLine();
// INSERTAR
        if (opcion == 1) {

            System.out.print("Fecha (AAAA-MM-DD): ");
            factura.setFecha_fact(sc.nextLine());

            
            System.out.print("Numero factura: ");
            factura.setN_factura(sc.nextLine());

            System.out.print("Valor total: ");
            factura.setValortotal(sc.nextLine());
            
            System.out.println("Seleccione Metodo de Pago:");
            System.out.println("1. Efectivo");
            System.out.println("2. Tarjeta");
            System.out.println("3. Transferencia");
            System.out.print("Opcion: ");
            int metodo = sc.nextInt();
            factura.setId_metodopago(metodo);

            System.out.print("ID Usuario: ");
            factura.setId_usuarios(sc.nextInt());

            if (dao.insertar(factura))
                System.out.println("Factura insertada correctamente");
            else
                System.out.println("Error al insertar");
// ACTUALIZAR
        } else if (opcion == 2) {

            System.out.print("ID de la factura a actualizar: ");
            factura.setId_Fact_Cabecera(sc.nextInt());
            sc.nextLine();

            System.out.print("Nueva fecha (AAAA-MM-DD): ");
            factura.setFecha_fact(sc.nextLine());

            System.out.print("Nuevo numero: ");
            factura.setN_factura(sc.nextLine());

            System.out.print("Nuevo valor total: ");
            factura.setValortotal(sc.nextLine());

            System.out.print("Nuevo ID Metodo Pago: ");
            factura.setId_metodopago(sc.nextInt());

            System.out.print("Nuevo ID Usuario: ");
            factura.setId_usuarios(sc.nextInt());

            if (dao.actualizar(factura))
                System.out.println("Factura actualizada correctamente");
            else
                System.out.println("Error al actualizar");
// ELIMINAR
        } else if (opcion == 3) {

            System.out.print("ID de la factura a eliminar: ");
            int id = sc.nextInt();

            if (dao.eliminar(id))
                System.out.println("Factura eliminada correctamente");
            else
                System.out.println("Error al eliminar");
        }

        sc.close();
    }
}