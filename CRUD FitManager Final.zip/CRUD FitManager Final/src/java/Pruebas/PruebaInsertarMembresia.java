package Pruebas;

import Controlador.MembresiasDAO;
import Modelo.Membresias;
import java.util.Scanner;

public class PruebaInsertarMembresia {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MembresiasDAO dao = new MembresiasDAO();
        Membresias m = new 
        
        
        Membresias();

        System.out.println("1. Insertar");
        System.out.println("2. Actualizar");
        System.out.println("3. Eliminar");
        System.out.print("Seleccione opcion: ");
        int opcion = sc.nextInt();
        sc.nextLine();
// INSERTAR
        if (opcion == 1) {

            System.out.print("Precio: ");
            m.setPrecio(sc.nextDouble());
            sc.nextLine();

            System.out.print("Tipo: ");
            m.setTipo(sc.nextLine());

            System.out.print("Duracion en dias: ");
            m.setDuracion_dias(sc.nextInt());
            
            if (dao.insertar(m))
                System.out.println("Membresia insertada correctamente");
            else
                System.out.println("Error al insertar");
//  ACTUALIZAR 
        } else if (opcion == 2) {

            System.out.print("ID a actualizar: ");
            m.setId_Membresias(sc.nextInt());
            sc.nextLine();

            System.out.print("Nuevo precio: ");
            m.setPrecio(sc.nextDouble());
            sc.nextLine();

            System.out.print("Nuevo tipo: ");
            m.setTipo(sc.nextLine());

            System.out.print("Nueva duracion en dias: ");
            m.setDuracion_dias(sc.nextInt());
            
            if (dao.actualizar(m))
                System.out.println("Membresia actualizada correctamente");
            else
                System.out.println("Error al actualizar");

// ELIMINAR
        } else if (opcion == 3) {

            System.out.print("ID a eliminar: ");
            int id = sc.nextInt();

            if (dao.eliminar(id))
                System.out.println("Membresia eliminada correctamente");
            else
                System.out.println("Error al eliminar");
        }

        sc.close();
    }
}