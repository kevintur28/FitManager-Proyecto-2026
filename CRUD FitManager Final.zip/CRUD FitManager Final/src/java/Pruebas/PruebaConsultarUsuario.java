package Pruebas;

import Controlador.UsuariosDAO;
import java.util.Scanner;
import modelo.Usuarios;

public class PruebaConsultarUsuario {

    public static void main(String[] args) {

        UsuariosDAO usuariosDAO = new UsuariosDAO();
        Scanner sc = new Scanner(System.in);

        // Pedir EMAIL al usuario
        System.out.print("Ingrese el email del usuario: ");
        String email = sc.nextLine();

        Usuarios usuario = usuariosDAO.consultarPorEmail(email);

        if (usuario != null) {
            System.out.println("\n✅ Usuario encontrado:");
            System.out.println("ID del usuario: " + usuario.getId_Usuarios());
            System.out.println("Nombres: " + usuario.getNombre());
            System.out.println("Apellidos: " + usuario.getApellido());
            System.out.println("Identificacion: " + usuario.getDocumento());
            System.out.println("Correo: " + usuario.getEmail());
            System.out.println("Password: " + usuario.getPassword());
            System.out.println("ID tipo documento: " + usuario.getId_TipoDocumento());
            System.out.println("ID rol: " + usuario.getId_Roles());

        } else {
            System.out.println("\n❌ No se encontró el usuario con email: " + email);
        }
    }
}