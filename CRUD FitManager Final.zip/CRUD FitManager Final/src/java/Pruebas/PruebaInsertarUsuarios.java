package Pruebas;

import Controlador.UsuariosDAO;
import java.util.List;
import java.util.Scanner;
import modelo.Usuarios;

public class PruebaInsertarUsuarios {

    public static void main(String[] args) {

        UsuariosDAO dao = new UsuariosDAO();
        Scanner sc = new Scanner(System.in);

        System.out.println("1. Insertar");
        System.out.println("2. Actualizar");
        System.out.println("3. Eliminar");
        System.out.println("4. Listar");
        System.out.print("Seleccione opcion: ");

        int opcion = sc.nextInt();
        sc.nextLine();

        Usuarios u = new Usuarios();

        
        switch (opcion) {

            // INSERTAR
            case 1:
                System.out.print("Nombre: ");
                u.setNombre(sc.nextLine());

                System.out.print("Apellido: ");
                u.setApellido(sc.nextLine());

                System.out.print("Documento: ");
                u.setDocumento(sc.nextLine());

                System.out.print("Email: ");
                u.setEmail(sc.nextLine());
                
                System.out.print("Password: ");
                u.setPassword(sc.nextLine());
                
                System.out.print("Rol: ");
                u.setId_Roles(sc.nextInt());
                sc.nextLine();
                
                System.out.print("Id de Membresias: ");
                u.setId_Membresias(sc.nextInt());
                

                System.out.println("Tipos de Documento:");
                System.out.println("1. Tarjeta de Identidad (T.I)");
                System.out.println("2. Cedula de Ciudadania (C.C)");
                System.out.println("3. Cedula de Extranjeria (C.E)");
                System.out.println("4. Permiso Especial de Permanencia (P.E.P)");                
                System.out.print("Seleccione ID TipoDocumento: ");
                u.setId_TipoDocumento(sc.nextInt());

                if (dao.insertar(u)) {
                    System.out.println("\n✅ Usuario insertado correctamente");
                } else {
                    System.out.println("\n❌ Error al insertar");
                }
                break;

            // ACTUALIZAR
            case 2:
                System.out.print("ID Usuario a actualizar: ");
                u.setId_Usuarios(sc.nextInt());
                sc.nextLine();

                System.out.print("Nuevo Nombre: ");
                u.setNombre(sc.nextLine());

                System.out.print("Nuevo Apellido: ");
                u.setApellido(sc.nextLine());

                System.out.print("Nuevo Documento: ");
                u.setDocumento(sc.nextLine());

                System.out.print("Nuevo Email: ");
                u.setEmail(sc.nextLine());

                System.out.print("Nuevo Password: ");
                u.setPassword(sc.nextLine());

                System.out.print("Nuevo ID TipoDocumento: ");
                u.setId_TipoDocumento(sc.nextInt());

                System.out.print("Nuevo ID Rol: ");
                u.setId_Roles(sc.nextInt());
                
                System.out.print("Nuevo Id de Membresias: ");
                u.setId_Membresias(sc.nextInt());

                if (dao.actualizar(u)) {
                    System.out.println("\n✅ Usuario actualizado");
                } else {
                    System.out.println("\n❌ Error al actualizar");
                }
                break;

            // ELIMINAR
            case 3:
                System.out.print("ID Usuario a eliminar: ");
                int idEliminar = sc.nextInt();

                if (dao.eliminar(idEliminar)) {
                    System.out.println("\n✅ Usuario eliminado");
                } else {
                    System.out.println("\n❌ Error al eliminar");
                }
                break;

            // LISTAR
            case 4:
                List<Usuarios> lista = dao.listar();

                System.out.println("\n===== LISTA DE USUARIOS =====");
                for (Usuarios user : lista) {
                    System.out.println(
                        "ID: " + user.getId_Usuarios() +
                        " | Nombre: " + user.getNombre() +
                        " | Apellido: " + user.getApellido() +
                        " | Documento: " + user.getDocumento() +
                        " | Email: " + user.getEmail() +
                        " | Password: " + user.getPassword() + // 🔥 agregado
                        " | TipoDoc: " + user.getId_TipoDocumento() +
                        " | Rol: " + user.getId_Roles()
                    );
                }
                break;

            default:
                System.out.println("\n❌ Opción inválida");
        }

        sc.close();
    }
}